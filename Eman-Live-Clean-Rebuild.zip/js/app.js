/* EMAN LIVE - CLEAN REBUILD */
const SUPABASE_URL="https://kzuaaihvehqhipwmrzal.supabase.co";
const SUPABASE_KEY="sb_publishable_LsGL8Os9cgqLmItWgk0ADg_nBWuLs7I";
const TOKEN_SERVER_ID="emanlive-2j2epi";
const PAYMENT_ADDRESS="0xec05bb37867f5e75a706a1face5304fd40a8f54c";

const supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
let currentUser=null, profile=null, selectedCategory="Chat";
let liveCoverFile=null, partyCoverFile=null;
let liveRoom=null, localVideoTrack=null, localAudioTrack=null, hostRoomName=null, hostStartedAt=null, hostTimer=null;
let viewerRoom=null, viewerRoomName=null;
let partyRoom=null, partySeat=null, partyVideoTrack=null, partyAudioTrack=null;
let coins=0, beans=0, wealthXP=0, charmXP=0;
let authMode="login";
const gifts=[
  ["🌹","Rose",10],["❤️","Heart",20],["💋","Kiss",50],["☕","Coffee",100],["🎂","Cake",200],
  ["💎","Diamond",500],["👑","Crown",1000],["🚗","Super Car",5000],["💍","Ring",9999],
  ["🦄","Unicorn",12000],["🚀","Rocket",20000],["🏰","Castle",50000],["💰","Money Rain",100000],["🌈","Rainbow",200000]
];
const packages=[
  [7000,1],[35000,5],[70000,10],[210000,30],[350000,50],[700000,100],[2100000,300],[3500000,500],[7000000,1000]
];

document.addEventListener("DOMContentLoaded",async()=>{
  document.getElementById("liveCoverInput").addEventListener("change",e=>handleCover(e.target.files[0],"live"));
  document.getElementById("partyCoverInput").addEventListener("change",e=>handleCover(e.target.files[0],"party"));
  document.getElementById("profilePhotoInput").addEventListener("change",e=>uploadProfilePhoto(e.target.files[0]));
  document.getElementById("albumPhotoInput").addEventListener("change",e=>uploadAlbumPhoto(e.target.files[0]));
  await restoreSession();
  renderPackages(); renderGifts(); renderDrawerGifts();
  loadLiveRooms();
});

async function restoreSession(){
  const {data}=await supabaseClient.auth.getUser();
  currentUser=data?.user||null;
  if(currentUser) await loadAccount();
}
supabaseClient.auth.onAuthStateChange((_event,session)=>{
  currentUser=session?.user||null;
  if(currentUser) loadAccount();
});

function showScreen(name){
  closeQuickMenu();
  document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));
  const target=document.getElementById("screen-"+name);
  if(target) target.classList.add("active");
  document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.remove("active"));
  const nav=document.getElementById("nav"+name.charAt(0).toUpperCase()+name.slice(1));
  if(nav) nav.classList.add("active");
  if(name==="home") loadLiveRooms();
  if(name==="chat") refreshInbox();
  if(name==="me") loadAccount();
}
function openChat(){showScreen("chat")}
function openLiveSetup(){ if(!requireLogin())return; showScreen("live"); startPreview(); }
function openPartySetup(){ if(!requireLogin())return; document.querySelectorAll(".fullscreen-room").forEach(x=>x.classList.add("hidden")); document.getElementById("partySetup").classList.remove("hidden"); }
function toggleMeMenu(){document.getElementById("meQuickMenu").classList.toggle("hidden")}
function closeQuickMenu(){document.getElementById("meQuickMenu").classList.add("hidden")}
function openSettings(){closeQuickMenu();document.getElementById("settingsScreen").classList.remove("hidden")}
function closeSettings(){document.getElementById("settingsScreen").classList.add("hidden")}
function openAgency(){alert("My Agency is ready for the agency-management backend milestone.");}

async function requireLogin(){
  const {data}=await supabaseClient.auth.getUser();
  if(data?.user){currentUser=data.user;return true}
  openAuth();
  return false;
}
function openAuth(mode="login"){
  authMode=mode; updateAuthUI(); document.getElementById("authScreen").classList.remove("hidden");
}
function updateAuthUI(){
  const signup=authMode==="signup";
  document.getElementById("authTitle").textContent=signup?"Create Your Eman Live Account":"Welcome Back";
  document.getElementById("authSubtitle").textContent=signup?"Join Eman Live today":"Login to your Eman Live account";
  document.getElementById("authMainButton").textContent=signup?"✨ CREATE ACCOUNT":"🔐 LOGIN";
  document.getElementById("authSwitchButton").textContent=signup?"Already have an account? Login":"Don't have an account? Sign Up";
  document.getElementById("authConfirmPassword").classList.toggle("hidden",!signup);
}
function switchAuthMode(){authMode=authMode==="login"?"signup":"login";updateAuthUI();document.getElementById("authMessage").textContent=""}
async function handleAuth(){
  const email=document.getElementById("authEmail").value.trim(),pass=document.getElementById("authPassword").value,confirm=document.getElementById("authConfirmPassword").value,msg=document.getElementById("authMessage");
  if(!email||!pass){msg.textContent="Enter your email and password.";return}
  if(authMode==="signup"){
    if(pass.length<6){msg.textContent="Password must be at least 6 characters.";return}
    if(pass!==confirm){msg.textContent="Passwords do not match.";return}
    msg.textContent="Creating account…";
    const {data,error}=await supabaseClient.auth.signUp({email,password:pass});
    if(error){msg.textContent=error.message;return}
    currentUser=data.user;
    if(currentUser) await supabaseClient.from("profiles").upsert({id:currentUser.id,username:email.split("@")[0],name:email.split("@")[0]});
    msg.textContent=data.session?"Account created!":"Check your email to confirm your account.";
    if(data.session)setTimeout(()=>{document.getElementById("authScreen").classList.add("hidden");loadAccount()},700);
  }else{
    msg.textContent="Logging in…";
    const {data,error}=await supabaseClient.auth.signInWithPassword({email,password:pass});
    if(error){msg.textContent=error.message;return}
    currentUser=data.user;msg.textContent="Login successful!";setTimeout(()=>{document.getElementById("authScreen").classList.add("hidden");loadAccount()},500);
  }
}
async function logout(){await supabaseClient.auth.signOut();currentUser=null;document.getElementById("settingsScreen").classList.add("hidden");showScreen("home");alert("You have been logged out.")}

async function loadAccount(){
  if(!currentUser)return;
  const p=await supabaseClient.from("profiles").select("*").eq("id",currentUser.id).maybeSingle();
  profile=p.data||{};
  const w=await supabaseClient.from("wallets").select("*").eq("user_id",currentUser.id).maybeSingle();
  coins=Number(w.data?.coins||0);beans=Number(w.data?.beans||0);
  const l=await supabaseClient.from("user_levels").select("*").eq("user_id",currentUser.id).maybeSingle();
  wealthXP=Number(l.data?.wealth_xp||l.data?.wealth_level_xp||0);charmXP=Number(l.data?.charm_xp||l.data?.charm_level_xp||0);
  renderAccount();loadAlbum();loadWithdrawalHistory();loadGiftHistory();
}
function displayId(){return profile?.user_id||profile?.user_code||("ID"+String(currentUser?.id||"").replaceAll("-","").slice(0,8).toUpperCase())}
function renderAccount(){
  const name=profile?.name||profile?.username||currentUser?.email?.split("@")[0]||"Eman Live User";
  document.getElementById("meName").textContent=name;
  document.getElementById("meUserId").textContent=displayId();
  document.getElementById("meBio").textContent=profile?.bio||"Welcome to Eman Live 👋";
  const fields={name, bio:profile?.bio||"—",gender:profile?.gender||"—",birthday:profile?.birthday||"—",country:profile?.country||"—",language:profile?.language||"—"};
  Object.entries(fields).forEach(([k,v])=>{const el=document.getElementById("profile"+k.charAt(0).toUpperCase()+k.slice(1)+"Value");if(el)el.textContent=v});
  document.getElementById("headerCoins").textContent=coins.toLocaleString();
  document.getElementById("walletCoins").textContent=coins.toLocaleString();
  document.getElementById("walletBeans").textContent=beans.toLocaleString();
  document.getElementById("incomeBeans").textContent=beans.toLocaleString();
  document.getElementById("drawerCoins").textContent=coins.toLocaleString();
  const avatar=document.getElementById("meAvatar"); if(profile?.avatar_url){avatar.src=profile.avatar_url;avatar.style.display="block"}else avatar.style.display="none";
  renderLevels();
}
function openMeTab(tab,sub){
  if(!currentUser){openAuth();return}
  showScreen("me");
  document.querySelectorAll(".me-tabs button").forEach(b=>b.classList.remove("active"));
  document.querySelectorAll(".me-panel").forEach(p=>p.classList.remove("active"));
  document.getElementById("meTab"+tab.charAt(0).toUpperCase()+tab.slice(1)).classList.add("active");
  document.getElementById("mePanel"+tab.charAt(0).toUpperCase()+tab.slice(1)).classList.add("active");
  if(tab==="wallet"&&sub)openWalletSub(sub);
}
async function editProfileField(field){
  if(!currentUser)return;
  const labels={name:"Name",bio:"Bio",gender:"Gender",birthday:"Birthday",country:"Country",language:"Language"};
  const current=profile?.[field]||"";
  const value=prompt("Enter your "+labels[field],current);
  if(value===null)return;
  const {error}=await supabaseClient.from("profiles").upsert({id:currentUser.id,[field]:value});
  if(error)alert("Profile update error: "+error.message);else{profile[field]=value;renderAccount()}
}
function chooseProfilePhoto(){if(currentUser)document.getElementById("profilePhotoInput").click();else openAuth()}
async function uploadProfilePhoto(file){
  if(!file||!currentUser)return;
  const path=`${currentUser.id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  const up=await supabaseClient.storage.from("profile-pictures").upload(path,file,{upsert:true});
  if(up.error){alert("Photo upload error: "+up.error.message);return}
  const {data}=supabaseClient.storage.from("profile-pictures").getPublicUrl(path);
  const {error}=await supabaseClient.from("profiles").upsert({id:currentUser.id,avatar_url:data.publicUrl});
  if(error){alert(error.message);return}profile.avatar_url=data.publicUrl;renderAccount()
}
async function addAlbumPhoto(){if(!currentUser){openAuth();return}document.getElementById("albumPhotoInput").click()}
async function uploadAlbumPhoto(file){
  if(!file||!currentUser)return;
  const path=`${currentUser.id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  const up=await supabaseClient.storage.from("album-photos").upload(path,file,{upsert:false});
  if(up.error){alert("Album upload error: "+up.error.message);return}
  const {data}=supabaseClient.storage.from("album-photos").getPublicUrl(path);
  const {error}=await supabaseClient.from("album_photos").insert({user_id:currentUser.id,photo_url:data.publicUrl,storage_path:path});
  if(error){alert(error.message);return}loadAlbum()
}
async function loadAlbum(){
  const box=document.getElementById("albumGrid"); if(!currentUser){box.innerHTML="";return}
  const {data,error}=await supabaseClient.from("album_photos").select("*").eq("user_id",currentUser.id).order("created_at",{ascending:false});
  if(error){box.innerHTML='<div class="empty-card">Album is unavailable.</div>';return}
  box.innerHTML=(data||[]).map(x=>`<div class="album-item"><img src="${escapeHtml(x.photo_url)}"><button class="album-delete" onclick="deleteAlbumPhoto('${escapeHtml(x.id)}','${escapeHtml(x.storage_path||"")}')">×</button></div>`).join("")||'<div class="empty-card">No album photos yet.</div>';
}
async function deleteAlbumPhoto(id,path){
  if(!confirm("Delete this photo?"))return;
  if(path)await supabaseClient.storage.from("album-photos").remove([path]);
  await supabaseClient.from("album_photos").delete().eq("id",id);loadAlbum()
}

function renderPackages(){
  document.getElementById("coinPackages").innerHTML=packages.map(([c,p])=>`<div class="package"><strong>${formatCoins(c)} coins</strong><small>$${p} USD</small><button onclick="showPayment(${p},${c})">Recharge</button></div>`).join("")
}
function formatCoins(n){return n>=1000000?(n/1000000).toFixed(n%1000000?1:0)+"M":n>=1000?(n/1000).toFixed(n%1000?1:0)+"K":String(n)}
function showPayment(price,amount){alert(`Recharge selected: ${formatCoins(amount)} coins for $${price} USD.\n\nUSDT network: BNB Smart Chain · BEP20\nPayment address:\n${PAYMENT_ADDRESS}\n\nSend the payment and keep the transaction hash for verification.`)}
function copyPaymentAddress(){navigator.clipboard?.writeText(PAYMENT_ADDRESS).then(()=>alert("USDT BEP20 address copied."),()=>alert(PAYMENT_ADDRESS))}
function openWalletSub(sub){
  ["buy","shop","history"].forEach(x=>{document.getElementById("walletSub"+x.charAt(0).toUpperCase()+x.slice(1)).classList.toggle("active",x===sub);document.getElementById("walletSub"+x.charAt(0).toUpperCase()+x.slice(1)+"Panel").classList.toggle("active",x===sub)})
  if(sub==="history")loadGiftHistory()
}
function renderGifts(){
  document.getElementById("giftCatalogue").innerHTML=gifts.map(g=>giftHTML(g,false)).join("")
}
function renderDrawerGifts(){document.getElementById("drawerGifts").innerHTML=gifts.map(g=>giftHTML(g,true)).join("")}
function giftHTML(g,drawer){return `<div class="gift"><div class="emoji">${g[0]}</div><strong>${g[1]}</strong><small>🪙 ${g[2].toLocaleString()}</small><button onclick="sendGift('${g[0]}','${g[1]}',${g[2]})">${drawer?"Send":"Send Gift"}</button></div>`}
function openGiftDrawer(){if(!currentUser){openAuth();return}document.getElementById("giftDrawer").classList.remove("hidden");renderDrawerGifts()}
function closeGiftDrawer(){document.getElementById("giftDrawer").classList.add("hidden")}
async function sendGift(emoji,name,cost,qty=1){
  if(!currentUser){openAuth();return}
  if(coins<cost*qty){closeGiftDrawer();openMeTab("wallet","buy");alert("Not enough coins. Please recharge.");return}
  const hostId=viewerRoom?.remoteParticipants?.values().next().value?.identity||null;
  coins-=cost*qty;wealthXP+=cost*qty;
  await upsertWallet();
  if(hostId&&hostId.match(/^[0-9a-f-]{36}$/i)){
    await supabaseClient.from("gift_transactions").insert({sender_id:currentUser.id,receiver_id:hostId,gift_name:name,coin_cost:cost*qty,quantity:qty});
    await awardHostBeans(hostId,cost*qty);
  }
  await updateLevels();renderAccount();showGiftBurst(emoji,`${name} ×${qty}`);
  if(!document.getElementById("giftDrawer").classList.contains("hidden"))closeGiftDrawer();
}
async function awardHostBeans(hostId,coinsSent){
  const {data}=await supabaseClient.from("wallets").select("*").eq("user_id",hostId).maybeSingle();
  const newBeans=Number(data?.beans||0)+coinsSent*10;
  await supabaseClient.from("wallets").upsert({user_id:hostId,beans:newBeans});
}
async function upsertWallet(){await supabaseClient.from("wallets").upsert({user_id:currentUser.id,coins,beans})}
async function updateLevels(){
  const wealthLevel=Math.floor(wealthXP/100)+1,charmLevel=Math.floor(charmXP/100)+1;
  await supabaseClient.from("user_levels").upsert({user_id:currentUser.id,wealth_xp:wealthXP,charm_xp:charmXP,wealth_level:wealthLevel,charm_level:charmLevel})
  renderLevels()
}
function renderLevels(){
  const wl=Math.floor(wealthXP/100)+1,cl=Math.floor(charmXP/100)+1,wx=wealthXP%100,cx=charmXP%100;
  document.getElementById("wealthLevel").textContent=wl;document.getElementById("charmLevel").textContent=cl;
  document.getElementById("wealthXPText").textContent=`${wx} / 100 XP`;document.getElementById("charmXPText").textContent=`${cx} / 100 XP`;
  document.getElementById("wealthProgress").style.width=wx+"%";document.getElementById("charmProgress").style.width=cx+"%";
}
async function loadGiftHistory(){
  if(!currentUser)return;
  const {data}=await supabaseClient.from("gift_transactions").select("*").or(`sender_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`).order("created_at",{ascending:false}).limit(50);
  document.getElementById("giftHistory").innerHTML=(data||[]).map(x=>`<div class="history-item"><div>🎁 ${escapeHtml(x.gift_name||"Gift")} ×${x.quantity||1}<small>${new Date(x.created_at).toLocaleString()}</small></div><strong>🪙 ${Number(x.coin_cost||0).toLocaleString()}</strong></div>`).join("")||'<div class="empty-card">No gift history yet.</div>'
}
async function requestWithdrawal(){
  if(!currentUser){openAuth();return}
  const amount=Number(document.getElementById("withdrawAmount").value),address=document.getElementById("withdrawAddress").value.trim(),msg=document.getElementById("withdrawMessage");
  const needed=amount*10000;
  if(beans<needed){msg.textContent=`You need at least ${needed.toLocaleString()} beans for $${amount}.`;return}
  if(!address){msg.textContent="Enter your BNB Smart Chain · BEP20 address.";return}
  const {error}=await supabaseClient.from("withdrawals").insert({user_id:currentUser.id,amount_usd:amount,beans_amount:needed,usdt_address:address,status:"pending"});
  if(error){msg.textContent=error.message;return}
  beans-=needed;await upsertWallet();msg.textContent="Withdrawal request submitted. Payments are made Friday.";renderAccount();loadWithdrawalHistory()
}
async function loadWithdrawalHistory(){
  if(!currentUser)return;
  const {data}=await supabaseClient.from("withdrawals").select("*").eq("user_id",currentUser.id).order("created_at",{ascending:false}).limit(50);
  document.getElementById("withdrawalHistory").innerHTML=(data||[]).map(x=>`<div class="history-item"><div>$${Number(x.amount_usd||0)} withdrawal<small>${new Date(x.created_at).toLocaleString()}</small></div><strong>${escapeHtml(x.status||"pending")}</strong></div>`).join("")||'<div class="empty-card">No withdrawals yet.</div>'
}

function handleCover(file,type){
  if(!file)return;
  if(file.size>10*1024*1024){alert("Please choose an image under 10 MB.");return}
  if(type==="live")liveCoverFile=file;else partyCoverFile=file;
  const url=URL.createObjectURL(file),img=document.getElementById(type==="live"?"liveCoverPreview":"partyCoverPreview"),ph=document.getElementById(type==="live"?"coverPlaceholder":null);
  img.src=url;img.style.display="block";if(ph)ph.style.display="none";updateStartButtons()
}
function updateStartButtons(){
  const liveOk=!!liveCoverFile&&document.getElementById("liveTitleInput").value.trim().length>0;
  const partyOk=!!partyCoverFile&&document.getElementById("partyTitleInput").value.trim().length>0;
  document.getElementById("startLiveButton").disabled=!liveOk;document.getElementById("startPartyButton").disabled=!partyOk
}
document.getElementById("liveTitleInput").addEventListener("input",updateStartButtons);
document.getElementById("partyTitleInput").addEventListener("input",updateStartButtons);
function selectCategory(btn){document.querySelectorAll(".category").forEach(x=>x.classList.remove("active"));btn.classList.add("active");selectedCategory=btn.dataset.category}
async function uploadCoverToStorage(file,bucket){
  const path=`${currentUser.id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  const up=await supabaseClient.storage.from(bucket).upload(path,file,{upsert:true});
  if(up.error)throw up.error;
  return supabaseClient.storage.from(bucket).getPublicUrl(path).data.publicUrl
}
async function startLiveFromSetup(){
  if(!await requireLogin())return;
  const msg=document.getElementById("liveSetupMessage");msg.textContent="Uploading cover…";
  try{
    const coverUrl=await uploadCoverToStorage(liveCoverFile,"live-covers");
    const roomName="eman-"+currentUser.id.slice(0,8)+"-"+Date.now();
    const title=document.getElementById("liveTitleInput").value.trim();
    const {error}=await supabaseClient.from("live_rooms").insert({host_id:currentUser.id,room_name:roomName,title,cover_photo:coverUrl,live_type:"live",status:"live",viewer_count:0});
    if(error)throw error;
    await connectHostLive(roomName,title);
  }catch(e){console.error(e);msg.textContent="Start Live error: "+(e.message||e);alert(msg.textContent)}
}
async function getLiveKitToken(roomName){
  if(!window.LivekitClient?.TokenSource?.developmentTokenServer)throw new Error("LiveKit library is not loaded.");
  const ts=LivekitClient.TokenSource.developmentTokenServer(TOKEN_SERVER_ID);
  const result=await ts.fetch({roomName,participantName:"EmanUser-"+Date.now()});
  if(!result?.serverUrl||!result?.participantToken)throw new Error("LiveKit did not return connection details.");
  return result
}
async function connectHostLive(roomName,title){
  const creds=await getLiveKitToken(roomName);
  liveRoom=new LivekitClient.Room({adaptiveStream:true,dynacast:true});
  liveRoom.on(LivekitClient.RoomEvent.TrackSubscribed,(track,publication,participant)=>{
    if(track.kind==="video"){const v=document.getElementById("hostPreview");track.attach(v)}
  });
  await liveRoom.connect(creds.serverUrl,creds.participantToken);
  await liveRoom.localParticipant.setCameraEnabled(true);
  await liveRoom.localParticipant.setMicrophoneEnabled(true);
  document.getElementById("liveRoom").classList.add("hidden");
  document.getElementById("hostRoom").classList.remove("hidden");
  const pubs=liveRoom.localParticipant.videoTrackPublications;
  pubs.forEach(p=>{if(p.track){localVideoTrack=p.track;p.track.attach(document.getElementById("hostPreview"))}});
  liveRoom.localParticipant.audioTrackPublications.forEach(p=>{if(p.track)localAudioTrack=p.track});
  hostRoomName=roomName;hostStartedAt=Date.now();startHostTimer();
  stopPreview();
}
async function startPreview(){
  try{
    stopPreview();
    cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"},audio:true});
    document.getElementById("hostPreview").srcObject=cameraStream;
  }catch(e){console.warn("Camera preview:",e)}
}
let cameraStream=null;
function stopPreview(){if(cameraStream){cameraStream.getTracks().forEach(t=>t.stop());cameraStream=null}}
function startHostTimer(){clearInterval(hostTimer);hostTimer=setInterval(()=>{const s=Math.floor((Date.now()-hostStartedAt)/1000);document.getElementById("hostLiveTimer").textContent=new Date(s*1000).toISOString().substr(14,5)},1000)}
async function endLive(){
  clearInterval(hostTimer);
  if(hostRoomName)await supabaseClient.from("live_rooms").update({status:"ended",ended_at:new Date().toISOString()}).eq("room_name",hostRoomName);
  if(liveRoom)liveRoom.disconnect();
  liveRoom=null;hostRoomName=null;localVideoTrack=null;localAudioTrack=null;stopPreview();
  document.getElementById("hostRoom").classList.add("hidden");showScreen("home");loadLiveRooms()
}
function toggleHostMute(){if(localAudioTrack){localAudioTrack.enabled=!localAudioTrack.enabled;document.getElementById("hostMuteBtn").textContent=localAudioTrack.enabled?"🎤":"🔇"}}
function toggleHostCamera(){if(localVideoTrack){localVideoTrack.enabled=!localVideoTrack.enabled;document.getElementById("hostCameraBtn").textContent=localVideoTrack.enabled?"📹":"🚫"}}
async function flipHostCamera(){if(!localVideoTrack)return;try{await localVideoTrack.restartTrack({facingMode:localVideoTrack.mediaStreamTrack.getSettings().facingMode==="user"?"environment":"user"})}catch(e){console.warn(e)}}

async function loadLiveRooms(){
  const box=document.getElementById("liveList");if(!box)return;
  const {data,error}=await supabaseClient.from("live_rooms").select("*").eq("status","live").order("created_at",{ascending:false}).limit(30);
  if(error){box.innerHTML='<div class="empty-card">Live rooms could not be loaded.</div>';return}
  box.innerHTML=(data||[]).map(x=>`<button class="live-tile" onclick="watchLive('${escapeHtml(x.room_name)}','${escapeHtml(x.title||"Live Room")}','${escapeHtml(x.cover_photo||"")}','${escapeHtml(x.host_id||"")}')"><img src="${escapeHtml(x.cover_photo||"https://placehold.co/600x400?text=Eman+Live")}"><div class="tile-body"><strong>${escapeHtml(x.title||"Live Room")}</strong><small>🔴 Live now · 👁 ${Number(x.viewer_count||0)}</small></div></button>`).join("")||'<div class="empty-card">No live streams yet.</div>'
}
async function watchLive(roomName,title,cover,hostId){
  if(!await requireLogin())return;
  try{
    const creds=await getLiveKitToken(roomName);
    viewerRoom=new LivekitClient.Room({adaptiveStream:true,dynacast:true});
    viewerRoom.on(LivekitClient.RoomEvent.TrackSubscribed,(track,publication,participant)=>{
      if(track.kind==="video")track.attach(document.getElementById("liveRemoteVideo"));
      document.getElementById("liveNoVideo").style.display="none";
    });
    viewerRoom.on(LivekitClient.RoomEvent.ParticipantConnected,p=>addRoomChat("System",`${p.identity} joined the live.`));
    await viewerRoom.connect(creds.serverUrl,creds.participantToken);
    viewerRoomName=roomName;
    document.getElementById("roomTitle").textContent=title;
    document.getElementById("roomHostName").textContent="Live Host";
    document.getElementById("liveRoom").classList.remove("hidden");
    await supabaseClient.from("live_rooms").update({viewer_count:1}).eq("room_name",roomName);
  }catch(e){alert("Live room error: "+(e.message||e))}
}
async function leaveLiveRoom(){
  if(viewerRoom)viewerRoom.disconnect();viewerRoom=null;viewerRoomName=null;
  document.getElementById("liveRoom").classList.add("hidden");showScreen("home")
}
function sendRoomChat(){const i=document.getElementById("roomChatInput"),t=i.value.trim();if(!t)return;addRoomChat("You",t);i.value=""}
function addRoomChat(name,text){const box=document.getElementById("roomChat"),d=document.createElement("div");d.className="chat-msg";d.textContent=`${name}: ${text}`;box.appendChild(d);box.scrollTop=box.scrollHeight}
function sendHeart(){let n=Number(document.getElementById("roomHeartCount").textContent||0)+1;document.getElementById("roomHeartCount").textContent=n;const b=document.getElementById("giftBurst");b.textContent="❤️💜💖";b.classList.remove("show");void b.offsetWidth;b.classList.add("show")}
function showGiftBurst(emoji,text){const b=document.getElementById("giftBurst");b.textContent=emoji;b.classList.remove("show");void b.offsetWidth;b.classList.add("show");const ban=document.getElementById("giftBanner");ban.textContent=text;ban.classList.remove("show");void ban.offsetWidth;ban.classList.add("show");setTimeout(()=>ban.classList.remove("show"),2500)}

async function startParty(){
  if(!await requireLogin())return;
  const msg=document.getElementById("partySetupMessage");msg.textContent="Uploading cover…";
  try{
    const cover=await uploadCoverToStorage(partyCoverFile,"party-covers");
    const roomName="eman-party-"+currentUser.id.slice(0,8)+"-"+Date.now();
    const title=document.getElementById("partyTitleInput").value.trim();
    const {error}=await supabaseClient.from("party_rooms").insert({host_id:currentUser.id,room_name:roomName,title,cover_photo:cover,status:"live"});
    if(error)throw error;
    document.getElementById("partyRoomTitle").textContent=title;
    document.getElementById("partySetup").classList.add("hidden");document.getElementById("partyRoom").classList.remove("hidden");
  }catch(e){msg.textContent="Start Party error: "+(e.message||e);alert(msg.textContent)}
}
async function joinPartySeat(){
  if(!currentUser){openAuth();return}
  if(partyRoom){alert("You are already in a seat.");return}
  const seatEl=[1,2,3,4].map(i=>document.getElementById("seat"+i)).find(x=>!x.dataset.occupied);
  if(!seatEl){alert("All 4 seats are occupied.");return}
  try{
    const creds=await getLiveKitToken("eman-party-main");
    partyRoom=new LivekitClient.Room({adaptiveStream:true,dynacast:true});
    partyRoom.on(LivekitClient.RoomEvent.TrackSubscribed,(track,pub,participant)=>{if(track.kind==="video")placePartyVideo(track,participant)});
    await partyRoom.connect(creds.serverUrl,creds.participantToken);
    await partyRoom.localParticipant.setCameraEnabled(true);await partyRoom.localParticipant.setMicrophoneEnabled(true);
    partySeat=Number(seatEl.id.replace("seat",""));seatEl.dataset.occupied="1";seatEl.querySelector("strong").textContent="You";
    partyRoom.localParticipant.videoTrackPublications.forEach(p=>{if(p.track){partyVideoTrack=p.track;placePartyVideo(p.track,{identity:"You"},partySeat)}});
    partyRoom.localParticipant.audioTrackPublications.forEach(p=>{if(p.track)partyAudioTrack=p.track});
  }catch(e){alert("Party seat error: "+(e.message||e))}
}
function placePartyVideo(track,participant,seatNumber){
  const el=seatNumber?document.getElementById("seat"+seatNumber):[1,2,3,4].map(i=>document.getElementById("seat"+i)).find(x=>!x.dataset.occupied);
  if(!el)return;el.dataset.occupied="1";el.querySelector("strong").textContent=participant.identity||"Guest";const area=el.querySelector(".seat-video");area.innerHTML="";const v=document.createElement("video");v.autoplay=true;v.playsInline=true;v.muted=true;track.attach(v);area.appendChild(v)
}
function togglePartyMute(){if(partyAudioTrack)partyAudioTrack.enabled=!partyAudioTrack.enabled}
function togglePartyCamera(){if(partyVideoTrack)partyVideoTrack.enabled=!partyVideoTrack.enabled}
async function leaveParty(){
  if(partyRoom)partyRoom.disconnect();partyRoom=null;partyVideoTrack=null;partyAudioTrack=null;partySeat=null;
  document.querySelectorAll(".party-seat").forEach((x,i)=>{delete x.dataset.occupied;x.querySelector("strong").textContent=`Seat ${i+1}`;x.querySelector(".seat-video").innerHTML="🛋️"});
  document.getElementById("partyRoom").classList.add("hidden");showScreen("home")
}
function sendPartyChat(){const i=document.getElementById("partyChatInput"),t=i.value.trim();if(!t)return;const box=document.getElementById("partyChat"),d=document.createElement("div");d.className="chat-msg";d.textContent="You: "+t;box.appendChild(d);box.scrollTop=box.scrollHeight;i.value=""}
function refreshInbox(){const box=document.getElementById("chatList");box.innerHTML='<div class="empty-card">📭 No private conversations yet.</div>'}

function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
