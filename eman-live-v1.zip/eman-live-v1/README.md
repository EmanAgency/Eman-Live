# EMAN LIVE — V1 Prototype

This is the first clickable front-end prototype for Eman Live.

## Included
- Home/live-room interface
- Eman Coins wallet mockup
- Virtual gifts
- Host leaderboard
- Go Live entry point
- Mobile-friendly layout

## Next production steps
1. Connect Supabase authentication and database.
2. Add real-time live video through a dedicated streaming provider.
3. Create coin purchase/payment backend.
4. Create gift ledger and host diamond ledger.
5. Add host withdrawal requests and admin approval.
6. Add moderation, reports, blocks and age/identity verification.
7. Package as an Android app.

This prototype uses demo balances only; it does not process real money or real video yet.
